/* contentScript.js
   Text selection detection, tooltip injection with Google button and synonyms.
   Nimbus Extension
*/

(() => {
  const MIN_WORD_LEN = 2;
  let tooltipEl = null;
  let selectionTimer = null;
  let currentWord = null;
  let currentSynonyms = [];
  let lastSelection = '';
  let manuallyClosed = false; // Track if user manually closed the tooltip
  let savedRange = null; // Store the selection range to maintain highlight
  let highlightOverlay = null; // Custom highlight overlay element
  let modalSettings = {
    placement: 'intuitive',
    draggable: true,
    showPhonetic: true,
    showExamples: true
  };
  let isDragging = false;

  // Function to find the best available voice for TTS
  function getBestVoice(lang = 'en-US') {
    if (!window.speechSynthesis) return null;
    
    // Ensure voices are loaded (they load asynchronously)
    let voices = window.speechSynthesis.getVoices();
    if (!voices || voices.length === 0) {
      // Try to load voices if not already loaded
      window.speechSynthesis.getVoices();
      voices = window.speechSynthesis.getVoices();
    }
    if (!voices || voices.length === 0) return null;
    
    // Priority order for voice selection (most natural/lifelike first)
    const voicePriorities = [
      // Google Neural voices (best quality)
      (v) => v.name.includes('Google') && (v.name.includes('Neural') || v.name.includes('Wavenet')),
      // Microsoft Neural voices
      (v) => v.name.includes('Microsoft') && (v.name.includes('Neural') || v.name.includes('Premium')),
      // Google voices (good quality)
      (v) => v.name.includes('Google'),
      // Microsoft voices
      (v) => v.name.includes('Microsoft'),
      // Apple voices (Mac/iOS)
      (v) => v.name.includes('Samantha') || v.name.includes('Alex') || v.name.includes('Victoria'),
      // Other premium/neural voices
      (v) => v.name.includes('Neural') || v.name.includes('Premium') || v.name.includes('Enhanced'),
      // Default to any voice matching the language
      (v) => v.lang.startsWith(lang.split('-')[0])
    ];
    
    // Filter voices by language first
    const langCode = lang.split('-')[0];
    let matchingVoices = voices.filter(v => v.lang.startsWith(langCode));
    
    // If no exact language match, try broader match
    if (matchingVoices.length === 0) {
      matchingVoices = voices.filter(v => v.lang.includes(langCode));
    }
    
    // If still no match, use all voices
    if (matchingVoices.length === 0) {
      matchingVoices = voices;
    }
    
    // Try to find the best voice based on priorities
    for (const priorityFn of voicePriorities) {
      const found = matchingVoices.find(priorityFn);
      if (found) return found;
    }
    
    // Fallback: prefer female voices (often sound more natural)
    const femaleVoice = matchingVoices.find(v => 
      v.name.toLowerCase().includes('female') || 
      v.name.includes('Samantha') || 
      v.name.includes('Victoria') ||
      v.name.includes('Karen') ||
      v.name.includes('Zira')
    );
    if (femaleVoice) return femaleVoice;
    
    // Last resort: return first matching voice
    return matchingVoices[0] || voices[0];
  }

  // Initialize subscription status
  let subscriptionActive = false;
  const SUBSCRIPTION_ID = 'nimbus_yearly_subscription';
  let usage = { used: 0, date: new Date().toISOString().slice(0,10), limit: 999999 };
  
  function safeStorageGet(keys, callback) {
    try {
      if (!chrome || !chrome.storage || !chrome.storage.local) return;
      chrome.storage.local.get(keys, callback);
    } catch (e) {
      console.warn('CursorIQ: Storage get failed', e);
    }
  }
  
  function safeStorageSet(data, callback) {
    try {
      if (!chrome || !chrome.storage || !chrome.storage.local) return;
      chrome.storage.local.set(data, callback);
    } catch (e) {
      console.warn('CursorIQ: Storage set failed', e);
    }
  }
  
  // Check subscription status via our API (Stripe backend)
  async function checkSubscription() {
    // NO BYPASS - Test actual payment flow even in development
    try {
      // First check if subscriptionActive is set in storage (set by popup/background)
      const storageResult = await new Promise((resolve) => {
        chrome.storage.local.get(['subscriptionActive', 'subscriptionId', 'subscriptionExpiry', 'userEmail'], resolve);
      });

      // If subscriptionActive is explicitly set to true in storage, trust it (but still verify expiry)
      if (storageResult.subscriptionActive === true) {
        const expiry = storageResult.subscriptionExpiry;
        if (expiry && new Date(expiry) > new Date()) {
          subscriptionActive = true;
          console.log('Nimbus: Subscription active from storage');
          return true;
        } else if (!expiry) {
          // No expiry date, but marked as active - verify with API
          console.log('Nimbus: Subscription marked active but no expiry, verifying...');
        } else {
          // Expired
          subscriptionActive = false;
          chrome.storage.local.remove(['subscriptionId', 'subscriptionExpiry', 'subscriptionActive']);
          return false;
        }
      }

      // Get subscription ID from storage
      const subscriptionId = storageResult.subscriptionId;
      const expiry = storageResult.subscriptionExpiry;
      const userEmail = storageResult.userEmail;

      if (!subscriptionId && !userEmail) {
        subscriptionActive = false;
        return false;
      }

      // Check if expired locally
      if (expiry && new Date(expiry) < new Date()) {
        subscriptionActive = false;
        chrome.storage.local.remove(['subscriptionId', 'subscriptionExpiry', 'subscriptionActive']);
        return false;
      }

      // Verify with API - try subscriptionId first, then email
      try {
        const licenseKey = subscriptionId || userEmail;
        if (!licenseKey) {
          subscriptionActive = false;
          return false;
        }

        const response = await fetch('https://nimbus-api-ten.vercel.app/api/verify-license', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ licenseKey }),
        });

        if (!response.ok) {
          subscriptionActive = false;
          return false;
        }

        const data = await response.json();
        if (data.valid) {
          subscriptionActive = true;
          // Update storage with latest info
          chrome.storage.local.set({
            subscriptionActive: true,
            subscriptionExpiry: data.expiryDate,
            subscriptionId: data.subscriptionId,
          });
          console.log('Nimbus: Subscription verified and active');
          return true;
        } else {
          subscriptionActive = false;
          chrome.storage.local.remove(['subscriptionId', 'subscriptionExpiry', 'subscriptionActive']);
          return false;
        }
      } catch (apiError) {
        // If API fails but expiry is still valid, allow access
        if (expiry && new Date(expiry) > new Date()) {
          subscriptionActive = true;
          return true;
        }
        subscriptionActive = false;
        return false;
      }
    } catch (e) {
      console.error('Nimbus: Error checking subscription:', e);
      subscriptionActive = false;
      return false;
    }
  }

  // Initialize subscription check on load
  checkSubscription().then(() => {
    safeStorageGet(['usage'], (res) => {
      if (chrome.runtime.lastError) return;
      if (res.usage) {
        usage = res.usage;
      }
    });
  });

  // Listen for storage changes
  try {
    if (chrome && chrome.storage && chrome.storage.onChanged) {
      chrome.storage.onChanged.addListener((changes, areaName) => {
        if (areaName === 'local') {
          if (changes.usage) {
            usage = changes.usage.newValue || usage;
          }
          // Re-check subscription when subscription data changes
          if (changes.subscriptionId || changes.subscriptionExpiry || changes.subscriptionActive || changes.userEmail) {
            console.log('Nimbus: Subscription storage changed, re-checking...', changes);
            checkSubscription().then((isActive) => {
              console.log('Nimbus: Subscription re-check result:', isActive);
              // If subscription just became active, close any upgrade prompts
              if (isActive && tooltipEl) {
                const upgradePrompt = tooltipEl.querySelector('[style*="Subscribe to Unlock"]');
                if (upgradePrompt) {
                  console.log('Nimbus: Subscription activated, closing upgrade prompt');
                  hideTooltip();
                }
              }
            });
          }
        }
      });
    }
  } catch (e) {
    console.warn('Nimbus: Could not set up storage listener', e);
  }
  
  // Also listen for messages from background/popup
  try {
    if (chrome && chrome.runtime && chrome.runtime.onMessage) {
      chrome.runtime.onMessage.addListener((msg) => {
        if (msg && msg.action === 'subscriptionActivated') {
          console.log('Nimbus: Received subscription activation message');
          checkSubscription().then((isActive) => {
            if (isActive && tooltipEl) {
              const upgradePrompt = tooltipEl.querySelector('[style*="Subscribe to Unlock"]');
              if (upgradePrompt) {
                console.log('Nimbus: Subscription activated via message, closing upgrade prompt');
                hideTooltip();
              }
            }
          });
        }
        return true; // Keep channel open for async response
      });
    }
  } catch (e) {
    console.warn('Nimbus: Message listener setup failed', e);
  }

  // Listen for purchase updates
  try {
    if (chrome && chrome.payments && chrome.payments.onPurchasesUpdated) {
      chrome.payments.onPurchasesUpdated.addListener((purchases) => {
        checkSubscription();
      });
    }
  } catch (e) {
    console.warn('Nimbus: Purchase listener setup failed', e);
  }

  console.log('Nimbus: Content script loaded on', window.location.href);

  // Listen for text selection
  document.addEventListener('mouseup', handleSelection);
  // Don't use selectionchange - it fires too often and causes issues
  // document.addEventListener('selectionchange', handleSelection);
  
  // Add keyboard shortcut for testing (Ctrl+Shift+E)
  document.addEventListener('keydown', (e) => {
    if (e.ctrlKey && e.shiftKey && e.key === 'E') {
      e.preventDefault();
      try {
        // Check extension context before proceeding
        if (!chrome || !chrome.runtime) {
          console.warn('CursorIQ: Extension context invalidated');
          return;
        }
        try {
          const runtimeId = chrome.runtime.id;
          if (!runtimeId) {
            return;
          }
        } catch (err) {
          console.warn('CursorIQ: Extension context invalidated:', err.message);
          return;
        }
        
        const selection = window.getSelection();
        if (selection && selection.toString().trim()) {
          handleSelection();
        } else {
          // Test with a dummy word
          triggerExplain({ word: 'test', context: 'test context', range: null, contextHash: 0 });
        }
      } catch (err) {
        if (err.message && err.message.includes('Extension context invalidated')) {
          console.warn('CursorIQ: Extension context invalidated');
        } else {
          console.error('CursorIQ: Error in keyboard shortcut handler', err);
        }
      }
    }
  });

  function handleSelection(e) {
    // QUICK CHECK: If click happened on tooltip/modal, ignore completely
    if (e && e.target) {
      const clickedElement = e.target;
      // Check if click is on tooltip or any of its children
      if (tooltipEl && (tooltipEl === clickedElement || tooltipEl.contains(clickedElement))) {
        return; // Clicked on tooltip, ignore selection
      }
      // Check if click is on highlight overlay
      if (highlightOverlay && (highlightOverlay === clickedElement || highlightOverlay.contains(clickedElement))) {
        return; // Clicked on highlight overlay, ignore selection
      }
    }
    
    // QUICK CHECK: If user is typing in an input field, ignore immediately
    const activeEl = document.activeElement;
    if (activeEl) {
      const tagName = activeEl.tagName?.toLowerCase();
      if (tagName === 'input' || tagName === 'textarea') {
        return; // User is typing in input, ignore selection
      }
      if (activeEl.contentEditable === 'true' || activeEl.isContentEditable) {
        return; // User is typing in contenteditable, ignore selection
      }
      const role = activeEl.getAttribute?.('role');
      if (role === 'textbox' || role === 'searchbox' || role === 'combobox' || role === 'search') {
        return; // User is in a search/textbox, ignore selection
      }
    }
    
    // If tooltip is currently visible, don't process new selections
    if (tooltipEl && document.body.contains(tooltipEl)) {
      return; // Tooltip is visible, ignore new selections
    }
    
    // Check extension context FIRST before doing anything
    try {
      if (!chrome || !chrome.runtime) {
        // Extension context invalidated - silently return
        return;
      }
      // Check if runtime.id exists (will throw if context invalidated)
      try {
        const runtimeId = chrome.runtime.id;
        if (!runtimeId) {
          return;
        }
      } catch (e) {
        // Extension context invalidated
        return;
      }
    } catch (e) {
      // Extension context invalidated - silently return
      return;
    }

    // Clear any existing timer
    if (selectionTimer) {
      clearTimeout(selectionTimer);
      selectionTimer = null;
    }

    try {
      const selection = window.getSelection();
      if (!selection || selection.rangeCount === 0) {
        // No selection - DON'T auto-remove if tooltip exists
        // Only remove if user explicitly clicks outside AND tooltip wasn't manually closed
        // For now, disable auto-close entirely - user must click X or click away
        return;
      }

      const selectedText = selection.toString().trim();
      if (!selectedText || selectedText.length < MIN_WORD_LEN) {
        return;
      }

      // Get the range early for positioning and save it to maintain highlight
      let range = null;
      try {
        if (selection.rangeCount > 0) {
          range = selection.getRangeAt(0);
          // Clone and save the range to maintain highlight
          savedRange = range.cloneRange();
        }
      } catch (e) {
        console.warn('CursorIQ: Error getting range', e);
        savedRange = null;
      }

      // Check if selection is an email address
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (emailRegex.test(selectedText)) {
        // It's an email - show email modal instead
        showEmailModal(selectedText, range);
        return;
      }

      // Check if selection is inside an input, textarea, or search field - DO THIS FIRST
      // Helper function to check if a node is inside an input/textarea
      const isInsideInput = (node) => {
        if (!node) return false;
        
        let current = node;
        let depth = 0;
        const maxDepth = 50; // Increased depth for very complex nested structures like Reddit
        
        while (current && current !== document.body && current !== document.documentElement && depth < maxDepth) {
          depth++;
          
          // Check if it's an input/textarea element
          if (current.nodeType === Node.ELEMENT_NODE) {
            const tagName = current.tagName?.toLowerCase();
            if (tagName === 'input' || tagName === 'textarea' || tagName === 'search') {
              return true;
            }
            // Check for contenteditable - but ONLY if it's actually an input field
            // Don't block contenteditable divs that are just page content (like Reddit posts)
            if (current.contentEditable === 'true' || current.isContentEditable) {
              // Only block if it has input-like attributes (placeholder, role, etc.)
              const role = current.getAttribute?.('role');
              const placeholder = current.getAttribute?.('placeholder') || '';
              const ariaLabel = current.getAttribute?.('aria-label') || '';
              const type = current.getAttribute?.('type');
              const id = current.getAttribute?.('id') || '';
              const className = current.className || '';
              const dataTestid = current.getAttribute?.('data-testid') || '';
              
              // Check for Reddit search bar specifically
              const isRedditSearch = (
                id.toLowerCase().includes('search') ||
                className.toLowerCase().includes('search') ||
                dataTestid.toLowerCase().includes('search') ||
                ariaLabel.toLowerCase().includes('search reddit') ||
                ariaLabel.toLowerCase().includes('search posts')
              ) && (
                className.toLowerCase().includes('input') ||
                className.toLowerCase().includes('field') ||
                className.toLowerCase().includes('box') ||
                placeholder.toLowerCase().includes('search')
              );
              
              // Only block if it's clearly an input field
              if (role === 'textbox' || role === 'searchbox' || role === 'combobox' || 
                  type === 'search' || type === 'text' ||
                  placeholder.length > 0 || 
                  ariaLabel.toLowerCase().includes('search') ||
                  ariaLabel.toLowerCase().includes('input') ||
                  isRedditSearch) {
                return true;
              }
              
              // Check if it's inside a form or has input-like parent
              let parent = current.parentElement;
              let parentDepth = 0;
              while (parent && parent !== document.body && parentDepth < 5) {
                const parentTag = parent.tagName?.toLowerCase();
                const parentRole = parent.getAttribute?.('role');
                const parentId = parent.getAttribute?.('id') || '';
                const parentClass = parent.className || '';
                
                // Check for Reddit search container
                const isRedditSearchContainer = (
                  parentId.toLowerCase().includes('search') ||
                  parentClass.toLowerCase().includes('search')
                ) && (
                  parentClass.toLowerCase().includes('input') ||
                  parentClass.toLowerCase().includes('field') ||
                  parentClass.toLowerCase().includes('box') ||
                  parentRole === 'search'
                );
                
                if (parentTag === 'form' || 
                    parentTag === 'input' ||
                    parentRole === 'search' ||
                    isRedditSearchContainer) {
                  return true;
                }
                parent = parent.parentElement;
                parentDepth++;
              }
              // If contenteditable doesn't have input attributes, don't block it
              // (it's probably just page content like Reddit posts/comments)
            }
          }
          
          // Move up the tree
          current = current.parentElement || current.parentNode;
        }
        return false;
      };
      
      try {
        // Simple check: Is selection inside an input/textarea?
        if (selection.rangeCount > 0 && range) {
          const startContainer = range.startContainer;
          const endContainer = range.endContainer;
          const commonAncestor = range.commonAncestorContainer;
          
          // Check if active element is an input and contains the selection
          const activeElement = document.activeElement;
          if (activeElement && activeElement !== document.body) {
            const activeTag = activeElement.tagName?.toLowerCase();
            if ((activeTag === 'input' || activeTag === 'textarea') && 
                range && (activeElement.contains(commonAncestor) || activeElement === commonAncestor)) {
              return; // Selection is in active input, ignore
            }
            const activeRole = activeElement.getAttribute?.('role');
            if ((activeRole === 'textbox' || activeRole === 'searchbox' || activeRole === 'combobox' || activeRole === 'search') &&
                range && (activeElement.contains(commonAncestor) || activeElement === commonAncestor)) {
              return; // Selection is in active searchbox, ignore
            }
            if ((activeElement.contentEditable === 'true' || activeElement.isContentEditable) &&
                range && (activeElement.contains(commonAncestor) || activeElement === commonAncestor)) {
              const activeRole = activeElement.getAttribute?.('role');
              const activePlaceholder = activeElement.getAttribute?.('placeholder') || '';
              if (activeRole === 'textbox' || activeRole === 'searchbox' || activePlaceholder.length > 0) {
                return; // Selection is in contenteditable input, ignore
              }
            }
          }
          
          // Check if selection containers are inside input elements
          if (isInsideInput(startContainer) || isInsideInput(endContainer) || isInsideInput(commonAncestor)) {
            return; // Selection is in input, ignore
          }
        }
      } catch (e) {
        // If check fails, continue anyway
      }

      // Check word count - split and filter
      const words = selectedText.split(/\s+/).filter(w => w.trim().length > 0);
      
      // Anything OVER 2 words (3+ words) - show icon-only modal immediately, skip all dictionary/AI processing
      if (words.length > 2) {
        console.log('CursorIQ: 3+ words selected, showing icon-only modal:', selectedText);
        // Clear any existing timers to prevent dictionary lookup
        if (selectionTimer) {
          clearTimeout(selectionTimer);
          selectionTimer = null;
        }
        // Clear lastSelection to allow re-showing
        lastSelection = '';
        showIconOnlyModal(selectedText, range);
        return;
      }

    // Don't process if same selection AND tooltip is already showing
    // But allow if tooltip was just closed (lastSelection is empty)
    if (selectedText === lastSelection && tooltipEl) {
      return;
    }

    // Update lastSelection - this allows re-selecting after closing
    lastSelection = selectedText;

      // Get context (range already obtained earlier)
      let context = selectedText;
      
      try {
        if (range && range.commonAncestorContainer) {
          const parent = range.commonAncestorContainer.parentElement;
          if (parent && parent.innerText) {
            context = parent.innerText;
          }
        }
      } catch (e) {
        console.warn('CursorIQ: Error getting context', e);
      }

      // Extract first word or phrase (up to 2 words max)
      const term = words.join(' ');

      console.log('CursorIQ: Selection detected:', term);

      // Trigger explanation after a short delay
      selectionTimer = setTimeout(() => {
        try {
          // Check extension context again before triggering
          if (!chrome || !chrome.runtime || !chrome.runtime.id) {
            return;
          }
          
          const currentSelection = window.getSelection();
          if (currentSelection && currentSelection.toString().trim() === selectedText) {
            const contextStr = (context || selectedText || '').toString();
            triggerExplain({
              word: term,
              range: range,
              context: contextStr,
              contextHash: hashString(contextStr.slice ? contextStr.slice(0, 200) : contextStr.substring(0, 200))
            });
          }
        } catch (e) {
          if (e.message && e.message.includes('Extension context invalidated')) {
            console.warn('CursorIQ: Extension context invalidated during selection');
          } else {
            console.error('CursorIQ: Error in selection handler', e);
          }
        }
      }, 200); // Shorter delay for faster response
    } catch (e) {
      if (e.message && e.message.includes('Extension context invalidated')) {
        // Silently ignore - extension was reloaded
        return;
      }
      console.error('CursorIQ: Error in handleSelection', e);
    }
  }

  function triggerExplain(wordInfo) {
    if (!wordInfo.word || wordInfo.word.length < MIN_WORD_LEN) return;

    // Check if extension context is still valid BEFORE doing anything
    try {
      if (!chrome || !chrome.runtime || !chrome.runtime.id) {
        console.error('CursorIQ: Extension context invalidated - refresh page');
        alert('CursorIQ: Extension was reloaded. Please refresh this page (F5) to continue.');
        return;
      }
    } catch (e) {
      console.error('CursorIQ: Cannot access chrome.runtime', e);
      alert('CursorIQ: Extension error. Please refresh the page (F5).');
      return;
    }

    // Check subscription before allowing word lookup
    checkSubscription().then((isActive) => {
      if (!isActive) {
        // Show upgrade prompt
        showUpgradePrompt(wordInfo);
        return;
      }

      // reset daily usage if date changed
      const today = new Date().toISOString().slice(0,10);
      if (usage.date !== today) { usage.used = 0; usage.date = today; }

      // Track usage
      usage.used += 1;
      safeStorageSet({ usage });

      currentWord = wordInfo.word;
      showTooltip(wordInfo, "Thinking...", false, []); // Show loading state with empty synonyms

      console.log('Nimbus: Sending message to background for:', wordInfo.word);
      
      try {
        console.log('Nimbus: About to call chrome.runtime.sendMessage');
        console.log('Nimbus: chrome.runtime exists:', !!chrome.runtime);
        console.log('Nimbus: chrome.runtime.id:', chrome.runtime?.id);
        
        chrome.runtime.sendMessage({ type: 'explain', word: wordInfo.word, context: wordInfo.context }, (resp) => {
        console.log('CursorIQ: ========== CALLBACK FIRED ==========');
        console.log('CursorIQ: Callback executed!');
        console.log('CursorIQ: Response received:', resp);
        console.log('CursorIQ: Response type:', typeof resp);
        console.log('CursorIQ: chrome.runtime.lastError:', chrome.runtime.lastError);
        
        // Check for extension context invalidated
        if (chrome.runtime.lastError) {
          const errorMsg = chrome.runtime.lastError.message;
          console.error('CursorIQ: Runtime error in callback:', chrome.runtime.lastError);
          if (errorMsg && (errorMsg.includes('Extension context invalidated') || errorMsg.includes('message port closed'))) {
            console.warn('CursorIQ: Extension was reloaded. Please refresh the page.');
            showTooltip(wordInfo, "⚠️ Extension reloaded. Please refresh the page (F5).", true);
            return;
          }
          showTooltip(wordInfo, "Extension error: " + errorMsg);
          return;
        }
        
        if (!resp) {
          console.error('CursorIQ: No response from background');
          showTooltip(wordInfo, "No response from background service.");
          return;
        }
        if (resp.error) {
          console.error('CursorIQ: Background error', resp.error);
          showTooltip(wordInfo, `Error: ${resp.error}`);
          return;
        }
        console.log('CursorIQ: ========== RECEIVED RESPONSE ==========');
        console.log('CursorIQ: Got explanation', resp.explanation?.substring(0, 50));
        console.log('CursorIQ: isPerson:', resp.isPerson, 'personData:', resp.personData ? 'present' : 'missing');
        console.log('CursorIQ: Full response object:', resp);
        console.log('CursorIQ: Response keys:', Object.keys(resp || {}));
        console.log('CursorIQ: Got synonyms from response:', resp.synonyms);
        console.log('CursorIQ: Synonyms type:', typeof resp.synonyms, 'isArray:', Array.isArray(resp.synonyms));
        console.log('CursorIQ: Synonyms value (stringified):', JSON.stringify(resp.synonyms));
        console.log('CursorIQ: Synonyms value (direct):', resp.synonyms);
        console.log('CursorIQ: Synonyms length:', resp.synonyms?.length);
        
        // Save to recent searches
        saveToRecent(wordInfo.word);
        
        // Extract synonyms - ensure it's always an array
        let synonyms = [];
        if (resp.synonyms !== undefined && resp.synonyms !== null) {
          if (Array.isArray(resp.synonyms)) {
            synonyms = resp.synonyms.filter(s => s && typeof s === 'string' && s.trim());
            console.log('CursorIQ: Filtered synonyms array:', synonyms);
          } else if (typeof resp.synonyms === 'string') {
            synonyms = [resp.synonyms.trim()].filter(s => s);
          } else {
            synonyms = [String(resp.synonyms)].filter(s => s);
          }
        } else {
          console.warn('CursorIQ: WARNING - resp.synonyms is undefined or null!');
        }
        
        console.log('CursorIQ: Final synonyms array:', synonyms);
        console.log('CursorIQ: Final synonyms length:', synonyms.length);
        console.log('CursorIQ: About to call showTooltip with synonyms:', synonyms);
        console.log('CursorIQ: =======================================');
        
        // Check if this is person, organization, or place data
        if (resp.isPerson && resp.personData) {
          // Open hub and pass person data
          openHubWithPersonData(resp.personData, wordInfo.word);
        } else if (resp.isOrganization && resp.organizationData) {
          // Open hub and pass organization data
          openHubWithPersonData(resp.organizationData, wordInfo.word);
        } else if (resp.isPlace && resp.placeData) {
          // Open hub and pass place data
          openHubWithPersonData(resp.placeData, wordInfo.word);
        } else {
          showTooltip(wordInfo, resp.explanation || "No explanation returned.", false, synonyms, resp.pronunciation, resp.examples || []);
        }
        });
        
        // Add a timeout to detect if callback never fires
        setTimeout(() => {
          console.warn('Nimbus: WARNING - Callback may not have fired after 5 seconds');
        }, 5000);
      } catch (err) {
        console.error('Nimbus: Error sending message', err);
        if (err.message && err.message.includes('Extension context invalidated')) {
          showTooltip(wordInfo, "⚠️ Extension reloaded. Please refresh the page (F5).", true);
        } else {
          showTooltip(wordInfo, "Error: " + err.message, true);
        }
      }
    });
  }

  // Show upgrade prompt when subscription is not active - Branded subscribe tooltip with blue background
  function showUpgradePrompt(wordInfo) {
    // Create a proper branded subscribe tooltip with blue gradient background
    const tooltipContent = `
      <div style="text-align: center; padding: 30px 25px; background: linear-gradient(135deg, #1e3a8a 0%, #1e40af 30%, #2563eb 60%, #3b82f6 100%); border-radius: 12px;">
        <img src="${chrome.runtime.getURL('NimbusLogo.svg')}" alt="Nimbus" style="height: 36px; margin-bottom: 18px; filter: brightness(0) invert(1);" onerror="this.style.display='none'">
        <h3 style="margin: 0 0 12px 0; color: #ffffff; font-size: 20px; font-weight: 700;">Subscribe to Unlock</h3>
        <p style="margin: 0 0 8px 0; color: #e2e8f0; font-size: 14px; line-height: 1.6;">Get instant definitions, AI explanations, and context for any word or phrase</p>
        <div style="background: rgba(255,255,255,0.2); padding: 8px 12px; border-radius: 6px; margin: 0 0 22px 0; display: inline-block;">
          <span style="color: #ffffff; font-size: 13px; font-weight: 600;">✨ 3-Day Free Trial</span>
        </div>
        <div style="background: rgba(255,255,255,0.15); backdrop-filter: blur(10px); padding: 18px; border-radius: 10px; margin-bottom: 22px; border: 1px solid rgba(255,255,255,0.2);">
          <div style="font-size: 32px; font-weight: 700; color: #ffffff; margin-bottom: 5px;">£4.99</div>
          <div style="font-size: 13px; color: #cbd5e1;">per year</div>
        </div>
        <button id="nimbus-upgrade-btn" style="background: #ffffff; color: #1e3a8a; border: none; padding: 14px 28px; border-radius: 10px; cursor: pointer; font-size: 15px; font-weight: 600; width: 100%; transition: all 0.2s; box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);">
          Start Free Trial
        </button>
        <p style="margin: 18px 0 0 0; color: #94a3b8; font-size: 11px;">Click to open payment in extension</p>
      </div>
    `;
    
    // Use showTooltip with HTML flag to render properly
    showTooltip(wordInfo, tooltipContent, false, [], null, [], true);
    
    // Add click handler for upgrade button
    setTimeout(() => {
      const upgradeBtn = document.getElementById('nimbus-upgrade-btn');
      if (upgradeBtn) {
        upgradeBtn.addEventListener('click', (e) => {
          e.stopPropagation();
          // Open extension popup for payment
          chrome.runtime.sendMessage({ action: 'openPayment' }, (response) => {
            if (chrome.runtime.lastError) {
              // Fallback: try to open popup directly
              chrome.runtime.sendMessage({ action: 'openPopup' });
            }
          });
        });
        
        // Hover effect
        upgradeBtn.addEventListener('mouseenter', () => {
          upgradeBtn.style.background = '#f1f5f9';
          upgradeBtn.style.transform = 'scale(1.02)';
        });
        upgradeBtn.addEventListener('mouseleave', () => {
          upgradeBtn.style.background = '#ffffff';
          upgradeBtn.style.transform = 'scale(1)';
        });
      }
    }, 100);
  }

  function showTooltip(wordInfo, text, isWarning=false, synonyms=[], pronunciation=null, examples=[], isHtml=false) {
    // Reset manually closed flag when showing new tooltip
    manuallyClosed = false;
    removeTooltip();
    currentSynonyms = synonyms;
    
    // Maintain the text selection highlight
    maintainSelectionHighlight();
    
    // Load settings (refresh in case they changed)
    loadModalSettings();

    tooltipEl = document.createElement('div');
    tooltipEl.className = 'cursoriq-tooltip';
    if (isWarning) tooltipEl.classList.add('warning');
    
    // Prevent clicks on tooltip buttons from triggering selection detection
    // But allow dragging on the tooltip itself
    tooltipEl.addEventListener('mouseup', (e) => {
      // Only stop propagation for buttons and interactive elements
      if (e.target.tagName === 'BUTTON' || 
          e.target.tagName === 'A' || 
          e.target.closest('button') || 
          e.target.closest('a') ||
          e.target.closest('.cursoriq-icon-btn') ||
          e.target.closest('.cursoriq-copy-btn')) {
        e.stopPropagation();
      }
    });
    tooltipEl.addEventListener('click', (e) => {
      // Stop propagation for all clicks on tooltip to prevent selection detection
      e.stopPropagation();
    });
    
    // Make entire modal draggable if enabled
    if (modalSettings.draggable || modalSettings.placement === 'custom') {
      tooltipEl.style.cursor = 'move';
      
      let startX, startY, initialX, initialY;
      
      // Make modal draggable by clicking anywhere on it (but not on interactive elements)
      tooltipEl.addEventListener('mousedown', (e) => {
        // Don't start drag if clicking on buttons, links, or interactive elements
        if (e.target.tagName === 'BUTTON' || 
            e.target.tagName === 'A' || 
            e.target.closest('button') || 
            e.target.closest('a') ||
            e.target.closest('.cursoriq-synonym-tag') ||
            e.target.closest('.cursoriq-explanation') ||
            e.target.closest('.cursoriq-example-item') ||
            e.target.closest('.cursoriq-examples-container')) {
          return;
        }
        
        // Don't start drag if user is selecting text
        const selection = window.getSelection();
        if (selection && selection.toString().length > 0) {
          return;
        }
        
        e.preventDefault();
        e.stopPropagation();
        isDragging = true;
        tooltipEl.style.cursor = 'grabbing';
        
        const rect = tooltipEl.getBoundingClientRect();
        startX = e.clientX;
        startY = e.clientY;
        initialX = rect.left;
        initialY = rect.top;
        
        document.addEventListener('mousemove', handleDrag);
        document.addEventListener('mouseup', stopDrag);
      });
      
      function handleDrag(e) {
        if (!isDragging) return;
        e.preventDefault();
        
        const deltaX = e.clientX - startX;
        const deltaY = e.clientY - startY;
        
        const newX = initialX + deltaX;
        const newY = initialY + deltaY;
        
        // Keep modal within viewport
        const maxX = window.innerWidth - tooltipEl.offsetWidth;
        const maxY = window.innerHeight - tooltipEl.offsetHeight;
        
        const finalX = Math.max(0, Math.min(newX, maxX));
        const finalY = Math.max(0, Math.min(newY, maxY));
        
        tooltipEl.style.left = finalX + 'px';
        tooltipEl.style.top = finalY + 'px';
        tooltipEl.style.position = 'fixed';
        tooltipEl.style.transform = 'none';
        tooltipEl.style.margin = '0';
      }
      
      function stopDrag() {
        isDragging = false;
        tooltipEl.style.cursor = 'move';
        document.removeEventListener('mousemove', handleDrag);
        document.removeEventListener('mouseup', stopDrag);
        
        // Save position only if placement is set to 'custom'
        // This way, dragging only affects position when user explicitly wants custom placement
        if (tooltipEl && tooltipEl.style.position === 'fixed' && modalSettings.placement === 'custom') {
          const savedPos = {
            x: parseInt(tooltipEl.style.left) || 0,
            y: parseInt(tooltipEl.style.top) || 0
          };
          chrome.storage.local.set({ 
            modalPosition: savedPos
          });
        }
      }
    }

    // Close button - positioned in top right corner, halfway out (only for non-subscribe prompts)
    if (!isHtml) {
      const closeBtn = document.createElement('button');
      closeBtn.className = 'cursoriq-close-btn';
      closeBtn.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>';
      closeBtn.setAttribute('aria-label', 'Close');
      closeBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        e.preventDefault();
        // Mark as manually closed BEFORE clearing selection
        manuallyClosed = true;
        // Clear any pending timers
        if (selectionTimer) {
          clearTimeout(selectionTimer);
          selectionTimer = null;
        }
        // Clear the text selection
        const selection = window.getSelection();
        if (selection) {
          selection.removeAllRanges();
        }
        // Remove tooltip
        removeTooltip();
      });
      tooltipEl.appendChild(closeBtn);
    }

    // Header with word and copy button
    const header = document.createElement('div');
    header.className = 'cursoriq-header';
    
    const wordContainer = document.createElement('div');
    wordContainer.style.display = 'flex';
    wordContainer.style.alignItems = 'center';
    wordContainer.style.gap = '8px';
    
    const wordWrapper = document.createElement('div');
    wordWrapper.style.display = 'flex';
    wordWrapper.style.flexDirection = 'column';
    wordWrapper.style.gap = '4px';
    
    const wordSpan = document.createElement('span');
    wordSpan.className = 'cursoriq-word';
    wordSpan.textContent = currentWord || wordInfo.word;
    wordWrapper.appendChild(wordSpan);
    
    // Phonetic breakdown (pronunciation) - only show if setting enabled
    if (modalSettings.showPhonetic && pronunciation) {
      const phoneticSpan = document.createElement('span');
      phoneticSpan.className = 'cursoriq-phonetic';
      phoneticSpan.textContent = pronunciation;
      wordWrapper.appendChild(phoneticSpan);
    }
    
    wordContainer.appendChild(wordWrapper);
    
    // Button container for TTS and Copy buttons - stack them together
    const buttonContainer = document.createElement('div');
    buttonContainer.style.display = 'flex';
    buttonContainer.style.alignItems = 'center';
    buttonContainer.style.gap = '6px';
    buttonContainer.style.flexShrink = '0';
    buttonContainer.style.marginLeft = 'auto';
    
    // Text-to-speech button
    const ttsBtn = document.createElement('button');
    ttsBtn.className = 'cursoriq-tts-btn';
    ttsBtn.innerHTML = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M11 5L6 9H2v6h4l5 4V5z"></path><path d="M19.07 4.93a10 10 0 010 14.14M15.54 8.46a5 5 0 010 7.07"></path></svg>';
    ttsBtn.setAttribute('aria-label', 'Pronounce word');
    ttsBtn.setAttribute('title', 'Pronounce word');
    ttsBtn.style.cssText = 'width: 28px; height: 28px; padding: 0; background: transparent; border: none; color: #64748b; cursor: pointer; display: flex; align-items: center; justify-content: center; opacity: 0.7; transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1); flex-shrink: 0;';
    ttsBtn.addEventListener('mouseenter', () => {
      ttsBtn.style.opacity = '1';
      ttsBtn.style.color = '#475569';
      ttsBtn.style.transform = 'scale(1.1)';
    });
    ttsBtn.addEventListener('mouseleave', () => {
      if (!ttsBtn.classList.contains('playing')) {
        ttsBtn.style.opacity = '0.7';
        ttsBtn.style.color = '#64748b';
        ttsBtn.style.transform = 'scale(1)';
      }
    });
    ttsBtn.addEventListener('click', async (e) => {
      e.stopPropagation();
      e.preventDefault();
      
      if (ttsBtn.classList.contains('playing')) {
        if (window.speechSynthesis) {
          window.speechSynthesis.cancel();
        }
        ttsBtn.classList.remove('playing');
        ttsBtn.style.color = '#64748b';
        ttsBtn.style.transform = 'scale(1)';
        return;
      }
      
      ttsBtn.classList.add('playing');
      ttsBtn.style.color = '#1e3a8a';
      ttsBtn.style.opacity = '1';
      ttsBtn.style.transform = 'scale(1.15)';
      
      const wordToSpeak = currentWord || wordInfo.word;
      
      if ('speechSynthesis' in window) {
        chrome.storage.local.get(['settings'], (result) => {
          const lang = result.settings?.dictionaryLanguage || 'en';
          const langMap = {
            'en': 'en-US', 'es': 'es-ES', 'fr': 'fr-FR', 'de': 'de-DE', 'it': 'it-IT',
            'pt': 'pt-PT', 'ru': 'ru-RU', 'ja': 'ja-JP', 'zh': 'zh-CN', 'ko': 'ko-KR',
            'ar': 'ar-SA', 'hi': 'hi-IN', 'nl': 'nl-NL', 'sv': 'sv-SE', 'pl': 'pl-PL'
          };
          const langCode = langMap[lang] || 'en-US';
          
          // Ensure voices are loaded before creating utterance
          const speakWithBestVoice = () => {
            const utterance = new SpeechSynthesisUtterance(wordToSpeak);
            utterance.lang = langCode;
            
            // Get the best available voice
            const bestVoice = getBestVoice(langCode);
            if (bestVoice) {
              utterance.voice = bestVoice;
              utterance.lang = bestVoice.lang; // Use voice's native language
            }
            
            // Optimize for smooth, lifelike speech
            utterance.rate = 0.95; // Slightly slower for clarity and naturalness
            utterance.pitch = 1.0; // Natural pitch
            utterance.volume = 1.0; // Full volume
            
            utterance.onend = () => {
              ttsBtn.classList.remove('playing');
              ttsBtn.style.color = '#64748b';
              ttsBtn.style.opacity = '0.7';
              ttsBtn.style.transform = 'scale(1)';
            };
            
            utterance.onerror = () => {
              ttsBtn.classList.remove('playing');
              ttsBtn.style.color = '#64748b';
              ttsBtn.style.opacity = '0.7';
              ttsBtn.style.transform = 'scale(1)';
            };
            
            window.speechSynthesis.speak(utterance);
          };
          
          // Load voices if needed
          if (window.speechSynthesis.getVoices().length === 0) {
            window.speechSynthesis.addEventListener('voiceschanged', speakWithBestVoice, { once: true });
            // Trigger voices loading
            window.speechSynthesis.getVoices();
          } else {
            speakWithBestVoice();
          }
        });
      } else {
        console.warn('CursorIQ: Text-to-speech not supported');
        ttsBtn.classList.remove('playing');
        ttsBtn.style.color = '#64748b';
        ttsBtn.style.transform = 'scale(1)';
      }
    });
    buttonContainer.appendChild(ttsBtn);
    
    // Copy button
    const copyBtn = document.createElement('button');
    copyBtn.className = 'cursoriq-copy-btn';
    copyBtn.innerHTML = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path></svg>';
    copyBtn.setAttribute('aria-label', 'Copy word');
    copyBtn.setAttribute('title', 'Copy word');
    copyBtn.addEventListener('click', async (e) => {
      e.stopPropagation();
      e.preventDefault();
      // Only handle if this is our button
      if (!e.target.closest('.cursoriq-tooltip')) return;
      
      const wordToCopy = currentWord || wordInfo.word;
      
      // Add click animation
      copyBtn.classList.add('copied');
      
      try {
        await navigator.clipboard.writeText(wordToCopy);
      } catch (err) {
        console.error('CursorIQ: Failed to copy word', err);
        // Fallback for older browsers
        const textArea = document.createElement('textarea');
        textArea.value = wordToCopy;
        textArea.style.position = 'fixed';
        textArea.style.opacity = '0';
        textArea.style.pointerEvents = 'none';
        document.body.appendChild(textArea);
        textArea.select();
        try {
          document.execCommand('copy');
        } catch (e) {
          console.error('CursorIQ: Fallback copy failed', e);
        }
        document.body.removeChild(textArea);
      }
      
      // Remove animation class after transition
      setTimeout(() => {
        copyBtn.classList.remove('copied');
      }, 300);
    });
    buttonContainer.appendChild(copyBtn);
    
    wordContainer.appendChild(buttonContainer);
    
    // For HTML content (subscribe prompt), don't show header - just show the content with blue background
    if (isHtml) {
      // Skip header for subscribe prompts - show content directly
      // Override tooltip background to blue gradient for subscribe prompts
      tooltipEl.style.background = 'linear-gradient(135deg, #1e3a8a 0%, #1e40af 30%, #2563eb 60%, #3b82f6 100%) !important';
      tooltipEl.style.border = 'none !important';
      tooltipEl.style.boxShadow = '0 20px 25px -5px rgba(0, 0, 0, 0.2), 0 10px 10px -5px rgba(0, 0, 0, 0.1) !important';
      
      const contentDiv = document.createElement('div');
      contentDiv.innerHTML = text;
      contentDiv.style.padding = '0';
      contentDiv.style.margin = '0';
      tooltipEl.appendChild(contentDiv);
    } else {
      // Normal tooltip - show header and explanation
      header.appendChild(wordContainer);
      tooltipEl.appendChild(header);

      // Main explanation text container
      const explanationContainer = document.createElement('div');
      explanationContainer.style.position = 'relative';
      explanationContainer.style.padding = '0 18px 16px';
      
      const textDiv = document.createElement('div');
      textDiv.className = 'cursoriq-explanation';
      textDiv.textContent = text;
      textDiv.style.userSelect = 'text';
      textDiv.style.webkitUserSelect = 'text';
      textDiv.style.mozUserSelect = 'text';
      textDiv.style.msUserSelect = 'text';
      textDiv.style.cursor = 'text';
      textDiv.style.padding = '0 36px 0 0'; // Add right padding to prevent text from going under copy button
      textDiv.style.margin = '0';
      explanationContainer.appendChild(textDiv);
    
      // Add copy button for explanation text
      const copyExplanationBtn = document.createElement('button');
      copyExplanationBtn.className = 'cursoriq-copy-explanation-btn';
      copyExplanationBtn.innerHTML = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect><path d="M5 15H4a2 2 0 01-2-2V4a2 2 0 012-2h9a2 2 0 012 2v1"></path></svg>';
      copyExplanationBtn.setAttribute('aria-label', 'Copy explanation');
      copyExplanationBtn.setAttribute('title', 'Copy explanation');
      copyExplanationBtn.style.cssText = 'position: absolute; top: 0; right: 18px; width: 24px; height: 24px; padding: 0; background: rgba(241, 245, 249, 0.8); border: 1px solid rgba(226, 232, 240, 0.8); border-radius: 6px; color: #64748b; cursor: pointer; display: flex; align-items: center; justify-content: center; opacity: 0.7; transition: all 0.2s ease; z-index: 10;';
      copyExplanationBtn.addEventListener('mouseenter', () => {
        copyExplanationBtn.style.opacity = '1';
        copyExplanationBtn.style.background = 'rgba(241, 245, 249, 1)';
        copyExplanationBtn.style.borderColor = '#cbd5e1';
      });
      copyExplanationBtn.addEventListener('mouseleave', () => {
        if (!copyExplanationBtn.classList.contains('copied')) {
          copyExplanationBtn.style.opacity = '0.7';
          copyExplanationBtn.style.background = 'rgba(241, 245, 249, 0.8)';
          copyExplanationBtn.style.borderColor = 'rgba(226, 232, 240, 0.8)';
        }
      });
      copyExplanationBtn.addEventListener('click', async (e) => {
        e.stopPropagation();
        e.preventDefault();
        // Only handle if this is our button from our modal
        if (!tooltipEl || !tooltipEl.contains(e.target)) return;
        
        copyExplanationBtn.classList.add('copied');
        copyExplanationBtn.style.color = '#10b981';
        copyExplanationBtn.style.opacity = '1';
        
        // Get current text from the explanation div by querying the DOM
        const explanationDivCurrent = tooltipEl.querySelector('.cursoriq-explanation');
        const currentText = explanationDivCurrent ? explanationDivCurrent.textContent.trim() : text;
        
        console.log('CursorIQ: Copying explanation text:', currentText.substring(0, 50) + '...');
        
        try {
          await navigator.clipboard.writeText(currentText);
        } catch (err) {
          console.error('CursorIQ: Failed to copy explanation', err);
          // Fallback for older browsers
          const textArea = document.createElement('textarea');
          textArea.value = currentText;
          textArea.style.position = 'fixed';
          textArea.style.opacity = '0';
          textArea.style.pointerEvents = 'none';
          document.body.appendChild(textArea);
          textArea.select();
          try {
            document.execCommand('copy');
          } catch (e) {
            console.error('CursorIQ: Fallback copy failed', e);
          }
          document.body.removeChild(textArea);
        }
        
        setTimeout(() => {
          copyExplanationBtn.classList.remove('copied');
          copyExplanationBtn.style.color = '#64748b';
          copyExplanationBtn.style.opacity = '0.7';
        }, 2000);
      });
      explanationContainer.appendChild(copyExplanationBtn);
      tooltipEl.appendChild(explanationContainer);
    }

    // Examples section (if available and setting enabled)
    if (modalSettings.showExamples && examples && Array.isArray(examples) && examples.length > 0) {
      const examplesDiv = document.createElement('div');
      examplesDiv.className = 'cursoriq-examples-container';
      const examplesLabel = document.createElement('div');
      examplesLabel.className = 'cursoriq-examples-label';
      examplesLabel.innerHTML = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="16" y1="13" x2="8" y2="13"></line><line x1="16" y1="17" x2="8" y2="17"></line><polyline points="10 9 9 9 8 9"></polyline></svg> Examples';
      examplesDiv.appendChild(examplesLabel);
      
      const examplesList = document.createElement('div');
      examplesList.className = 'cursoriq-examples-list';
      examples.forEach(example => {
        const exampleItem = document.createElement('div');
        exampleItem.className = 'cursoriq-example-item';
        exampleItem.textContent = example;
        examplesList.appendChild(exampleItem);
      });
      examplesDiv.appendChild(examplesList);
      tooltipEl.appendChild(examplesDiv);
    }

    // Synonyms section
    console.log('CursorIQ: showTooltip called with synonyms:', synonyms);
    console.log('CursorIQ: synonyms type:', typeof synonyms, 'isArray:', Array.isArray(synonyms), 'length:', synonyms?.length);
    if (synonyms && Array.isArray(synonyms) && synonyms.length > 0) {
      console.log('CursorIQ: Rendering synonyms section with', synonyms.length, 'synonyms');
      const synonymsDiv = document.createElement('div');
      synonymsDiv.className = 'cursoriq-synonyms-container';
      const synonymsLabel = document.createElement('div');
      synonymsLabel.className = 'cursoriq-synonyms-label';
      synonymsLabel.innerHTML = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M8 3H5a2 2 0 00-2 2v3m18 0V5a2 2 0 00-2-2h-3m0 18h3a2 2 0 002-2v-3M3 16v3a2 2 0 002 2h3"/></svg> Synonyms';
      synonymsDiv.appendChild(synonymsLabel);

      const synonymsScroll = document.createElement('div');
      synonymsScroll.className = 'cursoriq-synonyms-scroll';
      synonyms.forEach(synonym => {
        const tag = document.createElement('span');
        tag.className = 'cursoriq-synonym-tag';
        tag.textContent = synonym;
        tag.addEventListener('click', (e) => {
          e.stopPropagation();
          // Replace current tooltip content instead of opening new modal
          replaceTooltipWithSynonym(synonym);
        });
        synonymsScroll.appendChild(tag);
      });
      synonymsDiv.appendChild(synonymsScroll);
      tooltipEl.appendChild(synonymsDiv);
    } else {
      console.log('CursorIQ: No synonyms to display');
    }

    // Action buttons container - bottom right icons (only show for non-subscribe prompts)
    if (!isHtml) {
      const actionsDiv = document.createElement('div');
      actionsDiv.className = 'cursoriq-actions';

      // Favorite button - icon only
      const favBtn = document.createElement('button');
      favBtn.className = 'cursoriq-fav-btn-icon';
      favBtn.innerHTML = '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg>';
      favBtn.setAttribute('aria-label', 'Add to favorites');
      favBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        toggleFavorite(currentWord || wordInfo.word);
        updateFavoriteButtonIcon(favBtn, currentWord || wordInfo.word);
      });
      actionsDiv.appendChild(favBtn);

      // Search button - icon only
      const searchBtn = document.createElement('button');
      searchBtn.className = 'cursoriq-search-btn-icon';
      searchBtn.innerHTML = '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/></svg>';
      searchBtn.setAttribute('aria-label', 'Search');
      searchBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        const searchUrl = `https://www.google.com/search?q=${encodeURIComponent(currentWord || wordInfo.word)}`;
        window.open(searchUrl, '_blank');
      });
      actionsDiv.appendChild(searchBtn);
      tooltipEl.appendChild(actionsDiv);
      
      // Update favorite button state
      updateFavoriteButtonIcon(favBtn, currentWord || wordInfo.word);
    }

    document.body.appendChild(tooltipEl);

    // Position tooltip based on settings
    positionTooltip(wordInfo);
  }
  
  // Show icon-only modal for text selections over 2 words (3+ words)
  function showIconOnlyModal(selectedText, range) {
    manuallyClosed = false;
    removeTooltip();
    
    // Save the range for visual highlight only (don't restore selection programmatically)
    if (range) {
      savedRange = range.cloneRange();
      // Create visual highlight overlay without restoring selection
      try {
        const rect = savedRange.getBoundingClientRect();
        if (rect.width > 0 && rect.height > 0) {
          // Remove any existing overlay first
          if (highlightOverlay) {
            highlightOverlay.remove();
            highlightOverlay = null;
          }
          
          highlightOverlay = document.createElement('div');
          highlightOverlay.style.position = 'fixed';
          highlightOverlay.style.left = rect.left + window.scrollX + 'px';
          highlightOverlay.style.top = rect.top + window.scrollY + 'px';
          highlightOverlay.style.width = rect.width + 'px';
          highlightOverlay.style.height = rect.height + 'px';
          highlightOverlay.style.backgroundColor = 'rgba(59, 130, 246, 0.3)'; // Blue highlight
          highlightOverlay.style.pointerEvents = 'none'; // Critical: don't block clicks
          highlightOverlay.style.zIndex = '2147483646'; // Just below tooltip
          highlightOverlay.style.borderRadius = '2px';
          highlightOverlay.className = 'cursoriq-highlight-overlay';
          document.body.appendChild(highlightOverlay);
        }
      } catch (err) {
        // If range is invalid, clear saved range
        savedRange = null;
      }
    }
    
    // Load settings for positioning
    loadModalSettings();
    
    tooltipEl = document.createElement('div');
    tooltipEl.className = 'cursoriq-tooltip cursoriq-icon-only-modal';
    
    // Prevent clicks on tooltip buttons from triggering selection detection
    tooltipEl.addEventListener('mouseup', (e) => {
      // Stop propagation for buttons and interactive elements
      if (e.target.tagName === 'BUTTON' || 
          e.target.closest('button') ||
          e.target.closest('.cursoriq-icon-btn')) {
        e.stopPropagation();
      }
    });
    tooltipEl.addEventListener('click', (e) => {
      // Stop propagation for all clicks on tooltip to prevent selection detection
      e.stopPropagation();
    });
    
    // Close button
    const closeBtn = document.createElement('button');
    closeBtn.className = 'cursoriq-close-btn';
    closeBtn.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>';
    closeBtn.setAttribute('aria-label', 'Close');
    closeBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      e.preventDefault();
      manuallyClosed = true;
      if (selectionTimer) {
        clearTimeout(selectionTimer);
        selectionTimer = null;
      }
      const selection = window.getSelection();
      if (selection) {
        selection.removeAllRanges();
      }
      removeTooltip();
    });
    tooltipEl.appendChild(closeBtn);
    
    // Icon buttons container
    const buttonsContainer = document.createElement('div');
    buttonsContainer.className = 'cursoriq-icon-buttons';
    
    // Copy button
    const copyBtn = document.createElement('button');
    copyBtn.className = 'cursoriq-icon-btn cursoriq-copy-icon-btn';
    copyBtn.innerHTML = '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#1e3a8a" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path></svg>';
    copyBtn.setAttribute('aria-label', 'Copy text');
    copyBtn.setAttribute('title', 'Copy text');
    copyBtn.addEventListener('click', async (e) => {
      e.stopPropagation();
      e.preventDefault();
      // Only handle if this is our button from our modal
      if (!tooltipEl || !tooltipEl.contains(e.target)) return;
      
      try {
        await navigator.clipboard.writeText(selectedText);
        copyBtn.classList.add('copied');
        setTimeout(() => {
          copyBtn.classList.remove('copied');
        }, 2000);
      } catch (err) {
        console.error('CursorIQ: Failed to copy text', err);
        // Fallback
        const textArea = document.createElement('textarea');
        textArea.value = selectedText;
        textArea.style.position = 'fixed';
        textArea.style.opacity = '0';
        textArea.style.pointerEvents = 'none';
        document.body.appendChild(textArea);
        textArea.select();
        try {
          document.execCommand('copy');
        } catch (e) {
          console.error('CursorIQ: Fallback copy failed', e);
        }
        document.body.removeChild(textArea);
      }
    });
    buttonsContainer.appendChild(copyBtn);
    
    // Sound/TTS button
    const soundBtn = document.createElement('button');
    soundBtn.className = 'cursoriq-icon-btn cursoriq-tts-icon-btn';
    soundBtn.innerHTML = '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#1e3a8a" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"></polygon><path d="M19.07 4.93a10 10 0 0 1 0 14.14M15.54 8.46a5 5 0 0 1 0 7.07"></path></svg>';
    soundBtn.setAttribute('aria-label', 'Read aloud');
    soundBtn.setAttribute('title', 'Read aloud');
    soundBtn.addEventListener('click', async (e) => {
      e.stopPropagation();
      e.preventDefault();
      // Only handle if this is our button from our modal
      if (!tooltipEl || !tooltipEl.contains(e.target)) return;
      
      if ('speechSynthesis' in window) {
        // Stop any current speech
        window.speechSynthesis.cancel();
        
        soundBtn.classList.add('playing');
        soundBtn.style.color = '#1e3a8a';
        soundBtn.style.transform = 'scale(1.1)';
        
        // Ensure voices are loaded before creating utterance
        const speakWithBestVoice = () => {
          const utterance = new SpeechSynthesisUtterance(selectedText);
          utterance.lang = 'en-US';
          
          // Get the best available voice
          const bestVoice = getBestVoice('en-US');
          if (bestVoice) {
            utterance.voice = bestVoice;
            utterance.lang = bestVoice.lang; // Use voice's native language
          }
          
          // Optimize for smooth, lifelike speech
          utterance.rate = 0.95; // Slightly slower for clarity and naturalness
          utterance.pitch = 1.0; // Natural pitch
          utterance.volume = 1.0; // Full volume
          
          utterance.onend = () => {
            soundBtn.classList.remove('playing');
            soundBtn.style.color = '';
            soundBtn.style.transform = '';
          };
          
          utterance.onerror = () => {
            soundBtn.classList.remove('playing');
            soundBtn.style.color = '';
            soundBtn.style.transform = '';
          };
          
          window.speechSynthesis.speak(utterance);
        };
        
        // Load voices if needed
        if (window.speechSynthesis.getVoices().length === 0) {
          window.speechSynthesis.addEventListener('voiceschanged', speakWithBestVoice, { once: true });
          // Trigger voices loading
          window.speechSynthesis.getVoices();
        } else {
          speakWithBestVoice();
        }
      } else {
        console.warn('CursorIQ: Text-to-speech not supported');
      }
    });
    buttonsContainer.appendChild(soundBtn);
    
    // Search button - opens hub and searches (using AI icon)
    const searchBtn = document.createElement('button');
    searchBtn.className = 'cursoriq-icon-btn cursoriq-search-icon-btn';
    const aiIconImg = document.createElement('img');
    aiIconImg.src = chrome.runtime.getURL('ai.svg');
    aiIconImg.style.width = '20px';
    aiIconImg.style.height = '20px';
    aiIconImg.style.display = 'block';
    aiIconImg.style.filter = 'none';
    aiIconImg.style.margin = 'auto';
    aiIconImg.style.objectFit = 'contain';
    searchBtn.appendChild(aiIconImg);
    searchBtn.setAttribute('aria-label', 'Search in hub');
    searchBtn.setAttribute('title', 'Search in hub');
    searchBtn.addEventListener('click', async (e) => {
      e.stopPropagation();
      e.preventDefault();
      // Only handle if this is our button from our modal
      if (!tooltipEl || !tooltipEl.contains(e.target)) return;
      
      // Store search term and open hub
      const searchTerm = selectedText.trim();
      console.log('Nimbus: Setting pending search:', searchTerm);
      
      chrome.storage.local.set({
        pendingSearch: {
          type: 'search',
          term: searchTerm
        }
      }, () => {
        console.log('Nimbus: Pending search set, attempting to open popup');
        // Try to open the popup
        chrome.runtime.sendMessage({
          action: 'openPopup'
        }, (response) => {
          if (chrome.runtime.lastError) {
            console.log('Nimbus: Could not open popup automatically, user will need to open manually');
          } else {
            console.log('Nimbus: Popup open message sent');
          }
        });
      });
      
      // Close the modal
      removeTooltip();
    });
    buttonsContainer.appendChild(searchBtn);
    
    tooltipEl.appendChild(buttonsContainer);
    document.body.appendChild(tooltipEl);
    
    // Position tooltip
    positionTooltip({ range: range });
  }
  
  // Show email modal (simplified version for email addresses)
  function showEmailModal(email, range) {
    manuallyClosed = false;
    removeTooltip();
    
    // Load settings for positioning
    loadModalSettings();
    
    tooltipEl = document.createElement('div');
    tooltipEl.className = 'cursoriq-tooltip cursoriq-email-modal';
    
    // Close button
    const closeBtn = document.createElement('button');
    closeBtn.className = 'cursoriq-close-btn';
    closeBtn.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>';
    closeBtn.setAttribute('aria-label', 'Close');
    closeBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      e.preventDefault();
      manuallyClosed = true;
      if (selectionTimer) {
        clearTimeout(selectionTimer);
        selectionTimer = null;
      }
      const selection = window.getSelection();
      if (selection) {
        selection.removeAllRanges();
      }
      removeTooltip();
    });
    tooltipEl.appendChild(closeBtn);
    
    // Header with email
    const header = document.createElement('div');
    header.className = 'cursoriq-header';
    
    const emailContainer = document.createElement('div');
    emailContainer.style.display = 'flex';
    emailContainer.style.alignItems = 'center';
    emailContainer.style.gap = '8px';
    
    const emailSpan = document.createElement('span');
    emailSpan.className = 'cursoriq-word';
    emailSpan.textContent = email;
    emailContainer.appendChild(emailSpan);
    
    // Copy button
    const copyBtn = document.createElement('button');
    copyBtn.className = 'cursoriq-copy-btn';
    copyBtn.innerHTML = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path></svg>';
    copyBtn.setAttribute('aria-label', 'Copy email');
    copyBtn.setAttribute('title', 'Copy email');
    copyBtn.addEventListener('click', async (e) => {
      e.stopPropagation();
      e.preventDefault();
      // Only handle if this is our button from our modal
      const emailModalEl = document.querySelector('.cursoriq-email-modal');
      if (!emailModalEl || !emailModalEl.contains(e.target)) return;
      
      try {
        await navigator.clipboard.writeText(email);
        copyBtn.classList.add('copied');
        copyBtn.innerHTML = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg>';
      } catch (err) {
        // Fallback for older browsers
        const textArea = document.createElement('textarea');
        textArea.value = email;
        textArea.style.position = 'fixed';
        textArea.style.opacity = '0';
        textArea.style.pointerEvents = 'none';
        document.body.appendChild(textArea);
        textArea.select();
        try {
          document.execCommand('copy');
        } catch (e) {
          console.error('CursorIQ: Fallback copy failed', e);
        }
        document.body.removeChild(textArea);
      }
      setTimeout(() => {
        copyBtn.classList.remove('copied');
        copyBtn.innerHTML = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path></svg>';
      }, 300);
    });
    emailContainer.appendChild(copyBtn);
    
    header.appendChild(emailContainer);
    tooltipEl.appendChild(header);
    
    // Action buttons container - bottom right icons
    const actionsDiv = document.createElement('div');
    actionsDiv.className = 'cursoriq-actions';
    
    // Search button - icon only
    const searchBtn = document.createElement('button');
    searchBtn.className = 'cursoriq-search-btn-icon';
    searchBtn.innerHTML = '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/></svg>';
    searchBtn.setAttribute('aria-label', 'Search email');
    searchBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      const searchUrl = `https://www.google.com/search?q=${encodeURIComponent(email)}`;
      window.open(searchUrl, '_blank');
    });
    actionsDiv.appendChild(searchBtn);
    
    tooltipEl.appendChild(actionsDiv);
    
    // Append to body
    document.body.appendChild(tooltipEl);
    
    // Position the email modal
    positionEmailModal(email, range);
  }
  
  // Position email modal (similar to positionTooltip but simpler)
  function positionEmailModal(email, range) {
    if (!tooltipEl || !range) return;
    
    const rect = range.getBoundingClientRect();
    const tooltipRect = tooltipEl.getBoundingClientRect();
    const viewportWidth = window.innerWidth;
    const viewportHeight = window.innerHeight;
    
    let left, top;
    
    // Simple positioning - prefer above, then below, then center
    const spaceAbove = rect.top;
    const spaceBelow = viewportHeight - rect.bottom;
    
    if (spaceAbove > tooltipRect.height + 20) {
      // Position above
      top = rect.top - tooltipRect.height - 12;
      left = rect.left + (rect.width / 2) - (tooltipRect.width / 2);
    } else if (spaceBelow > tooltipRect.height + 20) {
      // Position below
      top = rect.bottom + 12;
      left = rect.left + (rect.width / 2) - (tooltipRect.width / 2);
    } else {
      // Center on screen
      left = (viewportWidth / 2) - (tooltipRect.width / 2);
      top = (viewportHeight / 2) - (tooltipRect.height / 2);
    }
    
    // Keep within viewport
    left = Math.max(12, Math.min(left, viewportWidth - tooltipRect.width - 12));
    top = Math.max(12, Math.min(top, viewportHeight - tooltipRect.height - 12));
    
    tooltipEl.style.left = left + 'px';
    tooltipEl.style.top = top + 'px';
    tooltipEl.style.position = 'fixed';
    tooltipEl.style.display = 'block';
    tooltipEl.style.visibility = 'visible';
    tooltipEl.style.opacity = '1';
  }
  
  // Position tooltip based on placement setting
  function positionTooltip(wordInfo) {
    // Only use saved position if placement is explicitly set to 'custom'
    // Otherwise, always use placement-based positioning for new word selections
    chrome.storage.local.get(['modalPosition'], (result) => {
      // Only use saved position if placement is 'custom'
      if (modalSettings.placement === 'custom' && result.modalPosition && result.modalPosition.x && result.modalPosition.y) {
        tooltipEl.style.position = 'fixed';
        tooltipEl.style.left = result.modalPosition.x + 'px';
        tooltipEl.style.top = result.modalPosition.y + 'px';
        tooltipEl.style.transform = 'none';
        tooltipEl.style.margin = '0';
        tooltipEl.style.zIndex = '2147483647';
        tooltipEl.style.display = 'block';
        tooltipEl.style.visibility = 'visible';
        tooltipEl.style.opacity = '1';
        return; // Skip normal positioning if using saved position
      }
      
      // Normal placement-based positioning (always use for non-custom placements)
      let rect = null;
      try { 
        if (wordInfo && wordInfo.range) {
          rect = wordInfo.range.getBoundingClientRect();
        }
      } catch(e){ 
        rect = null;
      }
      
      if (!rect) {
        // Fallback to selection
        const selection = window.getSelection();
        if (selection && selection.rangeCount > 0) {
          try {
            rect = selection.getRangeAt(0).getBoundingClientRect();
          } catch(e) {}
        }
      }
      
      if (!rect) {
        rect = { left: 100, top: 100, height: 20, width: 40 };
      }
      
      performPlacementPositioning(wordInfo, rect);
    });
  }
  
  function performPlacementPositioning(wordInfo, rect) {
    const padding = 12;
    const tooltipWidth = 420; // max-width from CSS
    const tooltipHeight = 250; // estimated height
    
    const viewportWidth = window.innerWidth;
    const viewportHeight = window.innerHeight;
    
    let left, top;
    
    // Calculate position based on placement setting
    switch (modalSettings.placement) {
      case 'top':
        left = rect.left + (rect.width / 2) - (tooltipWidth / 2);
        top = rect.top - tooltipHeight - padding;
        break;
      case 'bottom':
        left = rect.left + (rect.width / 2) - (tooltipWidth / 2);
        top = rect.bottom + padding;
        break;
      case 'left':
        left = rect.left - tooltipWidth - padding;
        top = rect.top + (rect.height / 2) - (tooltipHeight / 2);
        break;
      case 'right':
        left = rect.right + padding;
        top = rect.top + (rect.height / 2) - (tooltipHeight / 2);
        break;
      case 'center':
        left = (viewportWidth / 2) - (tooltipWidth / 2);
        top = (viewportHeight / 2) - (tooltipHeight / 2);
        break;
      case 'custom':
        // For custom, default to center - user can drag to preferred position
        // Saved position will be loaded in positionTooltip function
        left = (viewportWidth / 2) - (tooltipWidth / 2);
        top = (viewportHeight / 2) - (tooltipHeight / 2);
        break;
      case 'intuitive':
      default:
        // Default behavior: below selection, centered horizontally
        left = rect.left + (rect.width / 2) - (tooltipWidth / 2);
        top = rect.bottom + padding;
        
        // If no room below, put it above
        if (top + tooltipHeight > viewportHeight - 10) {
          top = rect.top - tooltipHeight - padding;
          if (top < 10) {
            // Still no room, center vertically
            top = (viewportHeight / 2) - (tooltipHeight / 2);
          }
        }
        break;
    }
    
    // Keep tooltip on screen - adjust if off-screen
    // Horizontal positioning - ensure it's visible
    if (left < 10) {
      left = 10;
    } else if (left + tooltipWidth > viewportWidth - 10) {
      left = viewportWidth - tooltipWidth - 10;
    }
    
    // Vertical positioning - ensure it's visible
    if (top < 10) {
      top = 10;
    } else if (top + tooltipHeight > viewportHeight - 10) {
      top = viewportHeight - tooltipHeight - 10;
    }
    
    // Use fixed positioning (relative to viewport, not document)
    tooltipEl.style.position = 'fixed';
    tooltipEl.style.left = `${left}px`;
    tooltipEl.style.top = `${top}px`;
    tooltipEl.style.zIndex = '2147483647';
    
    console.log('CursorIQ: Tooltip positioned at', left, top, 'viewport:', viewportWidth, viewportHeight, 'rect:', rect);
    
    // Force visibility - make absolutely sure it's visible
    tooltipEl.style.display = 'block';
    tooltipEl.style.visibility = 'visible';
    tooltipEl.style.opacity = '1';
    tooltipEl.style.pointerEvents = 'auto';
    
    // Force visibility check and fix if needed
    setTimeout(() => {
      if (tooltipEl && tooltipEl.parentNode) {
        const tooltipRect = tooltipEl.getBoundingClientRect();
        const styles = window.getComputedStyle(tooltipEl);
        const isVisible = tooltipRect.width > 0 && tooltipRect.height > 0;
        
        console.log('CursorIQ: Tooltip check:', {
          exists: !!tooltipEl,
          inDOM: !!tooltipEl.parentNode,
          visible: isVisible,
          position: { left: tooltipRect.left, top: tooltipRect.top },
          size: { width: tooltipRect.width, height: tooltipRect.height },
          styles: {
            display: styles.display,
            visibility: styles.visibility,
            opacity: styles.opacity,
            zIndex: styles.zIndex
          }
        });
        
        // If tooltip has no size or is off-screen, force it visible
        if (!isVisible || tooltipRect.width === 0 || tooltipRect.height === 0) {
          console.error('CursorIQ: Tooltip not visible! Forcing...');
          tooltipEl.style.display = 'block';
          tooltipEl.style.visibility = 'visible';
          tooltipEl.style.opacity = '1';
          tooltipEl.style.left = `${(viewportWidth - tooltipWidth) / 2}px`;
          tooltipEl.style.top = `${(viewportHeight - tooltipHeight) / 2}px`;
        }
      } else {
        console.error('CursorIQ: Tooltip was removed before check!');
      }
    }, 100);

    // Don't remove on scroll immediately - wait a bit
    let scrollTimeout = null;
    document.addEventListener('scroll', () => {
      if (scrollTimeout) clearTimeout(scrollTimeout);
      scrollTimeout = setTimeout(() => {
        removeTooltip();
      }, 200);
    }, { once: false });
    
    // Keep tooltip visible - don't remove when clicking or hovering
    tooltipEl.addEventListener('mousedown', (e) => {
      e.stopPropagation();
    });
    
    tooltipEl.addEventListener('mouseenter', () => {
      // Clear any pending removal timers when hovering over tooltip
      if (selectionTimer) {
        clearTimeout(selectionTimer);
        selectionTimer = null;
      }
    });
  }

  // Function to maintain text selection highlight
  function maintainSelectionHighlight() {
    // Remove any existing highlight overlay
    if (highlightOverlay) {
      highlightOverlay.remove();
      highlightOverlay = null;
    }
    
    if (!savedRange) return;
    
    try {
      // Try to restore the selection programmatically
      const selection = window.getSelection();
      if (selection && savedRange) {
        selection.removeAllRanges();
        selection.addRange(savedRange.cloneRange());
      }
    } catch (e) {
      // If we can't restore selection, create a visual highlight overlay
      try {
        const rect = savedRange.getBoundingClientRect();
        if (rect.width > 0 && rect.height > 0) {
          highlightOverlay = document.createElement('div');
          highlightOverlay.style.position = 'fixed';
          highlightOverlay.style.left = rect.left + window.scrollX + 'px';
          highlightOverlay.style.top = rect.top + window.scrollY + 'px';
          highlightOverlay.style.width = rect.width + 'px';
          highlightOverlay.style.height = rect.height + 'px';
          highlightOverlay.style.backgroundColor = 'rgba(59, 130, 246, 0.3)'; // Blue highlight
          highlightOverlay.style.pointerEvents = 'none';
          highlightOverlay.style.zIndex = '2147483646'; // Just below tooltip
          highlightOverlay.style.borderRadius = '2px';
          highlightOverlay.className = 'cursoriq-highlight-overlay';
          document.body.appendChild(highlightOverlay);
          
          // Update highlight position on scroll
          const updateHighlight = () => {
            if (highlightOverlay && savedRange) {
              try {
                const rect = savedRange.getBoundingClientRect();
                highlightOverlay.style.left = rect.left + window.scrollX + 'px';
                highlightOverlay.style.top = rect.top + window.scrollY + 'px';
              } catch (e) {
                // Range might be invalid, remove overlay
                if (highlightOverlay) {
                  highlightOverlay.remove();
                  highlightOverlay = null;
                }
              }
            }
          };
          
          window.addEventListener('scroll', updateHighlight, { passive: true });
          window.addEventListener('resize', updateHighlight, { passive: true });
        }
      } catch (err) {
        // If range is invalid, clear saved range
        savedRange = null;
      }
    }
  }

  function removeTooltip() {
    // Remove highlight overlay when tooltip is removed
    if (highlightOverlay) {
      highlightOverlay.remove();
      highlightOverlay = null;
    }
    // Clear any pending timers
    if (selectionTimer) {
      clearTimeout(selectionTimer);
      selectionTimer = null;
    }
    
    if (tooltipEl && tooltipEl.parentNode) {
      tooltipEl.parentNode.removeChild(tooltipEl);
    }
    tooltipEl = null;
    currentWord = null;
    currentSynonyms = [];
    lastSelection = ''; // Reset so same word can be selected again
    
    // Clear text selection AFTER removing tooltip to avoid triggering events
    if (!manuallyClosed) {
      try {
        const selection = window.getSelection();
        if (selection && selection.rangeCount > 0) {
          selection.removeAllRanges();
        }
      } catch (e) {
        // Some sites may block selection clearing, that's okay
      }
    }
    
    // Reset manuallyClosed flag after a short delay to allow new selections
    setTimeout(() => {
      manuallyClosed = false;
    }, 500);
  }

  function toggleFavorite(word) {
    if (!word) return;
    
    try {
      if (!chrome || !chrome.storage) return;
      
      chrome.storage.local.get(['favorites'], (res) => {
        if (chrome.runtime.lastError) {
          console.warn('CursorIQ: Error getting favorites', chrome.runtime.lastError);
          return;
        }
        
        const favorites = res.favorites || [];
        const index = favorites.indexOf(word);
        let wasFavorited = index > -1;
        
        if (index > -1) {
          // Remove from favorites
          favorites.splice(index, 1);
          console.log('CursorIQ: Removed', word, 'from favorites');
        } else {
          // Add to favorites
          favorites.push(word);
          console.log('CursorIQ: Added', word, 'to favorites');
        }
        
        safeStorageSet({ favorites }, () => {
          // Update button after storage is saved
          const favBtn = tooltipEl?.querySelector('.cursoriq-fav-btn-icon');
          if (favBtn) {
            updateFavoriteButtonIcon(favBtn, word);
          }
        });
        
        // Also save to recent searches
        saveToRecent(word);
      });
    } catch (e) {
      console.warn('CursorIQ: Error toggling favorite', e);
    }
  }

  function updateFavoriteButton(btn, word) {
    if (!word || !btn) return;
    
    try {
      if (!chrome || !chrome.storage) return;
      
      chrome.storage.local.get(['favorites'], (res) => {
        if (chrome.runtime.lastError) return;
        
        const favorites = res.favorites || [];
        const isFavorited = favorites.includes(word);
        
        if (isFavorited) {
          btn.classList.add('favorited');
          btn.innerHTML = '<svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor" stroke="currentColor" stroke-width="2"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg> Favorited';
        } else {
          btn.classList.remove('favorited');
          btn.innerHTML = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg> Favorite';
        }
      });
    } catch (e) {
      console.warn('CursorIQ: Error updating favorite button', e);
    }
  }

  function updateFavoriteButtonIcon(btn, word) {
    if (!word || !btn) return;
    
    try {
      if (!chrome || !chrome.storage) return;
      
      chrome.storage.local.get(['favorites'], (res) => {
        if (chrome.runtime.lastError) {
          console.warn('CursorIQ: Error getting favorites', chrome.runtime.lastError);
          return;
        }
        
        const favorites = res.favorites || [];
        const isFav = favorites.indexOf(word) > -1;
        
        console.log('CursorIQ: Updating favorite button for', word, 'isFav:', isFav);
        
        if (isFav) {
          btn.innerHTML = '<svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor" stroke="currentColor" stroke-width="2"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg>';
          btn.style.color = '#dc2626';
          btn.style.opacity = '1';
        } else {
          btn.innerHTML = '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg>';
          btn.style.color = '#64748b';
          btn.style.opacity = '0.7';
        }
      });
    } catch (e) {
      console.warn('CursorIQ: Error updating favorite button icon', e);
    }
  }

  function saveToRecent(word) {
    if (!word) return;
    
    try {
      // Check if we're in incognito mode - don't save if so
      if (!chrome || !chrome.runtime || !chrome.runtime.id) return;
      
      // Send message to background to check incognito status
      chrome.runtime.sendMessage({ action: 'checkIncognito' }, (response) => {
        if (chrome.runtime.lastError) {
          console.warn('CursorIQ: Error checking incognito status', chrome.runtime.lastError);
          // If we can't check, proceed anyway (safer to save than not)
        } else if (response && response.isIncognito) {
          console.log('CursorIQ: Incognito mode detected, not saving to recent');
          return;
        }
        
        // Not in incognito, proceed with saving
        if (!chrome || !chrome.storage) return;
        
        chrome.storage.local.get(['recentSearches'], (res) => {
          if (chrome.runtime.lastError) return;
          
          let recent = res.recentSearches || [];
          
          // Migrate old format (strings) to new format (objects with timestamp)
          if (recent.length > 0 && typeof recent[0] === 'string') {
            recent = recent.map(w => ({ word: w, timestamp: Date.now() }));
          }
          
          // Remove if already exists (check word property if object, or direct match if string)
          recent = recent.filter(item => {
            const itemWord = typeof item === 'string' ? item : item.word;
            return itemWord !== word;
          });
          
          // Add to front with timestamp
          recent.unshift({ word: word, timestamp: Date.now() });
          
          // Remove entries older than 14 days
          const fourteenDaysAgo = Date.now() - (14 * 24 * 60 * 60 * 1000);
          recent = recent.filter(item => {
            const timestamp = typeof item === 'string' ? Date.now() : item.timestamp;
            return timestamp > fourteenDaysAgo;
          });
          
          // Keep only last 50
          recent = recent.slice(0, 50);
          
          safeStorageSet({ recentSearches: recent });
        });
      });
    } catch (e) {
      console.warn('CursorIQ: Error saving to recent', e);
    }
  }

  function replaceTooltipWithSynonym(synonym) {
    if (!tooltipEl || !tooltipEl.parentNode) {
      // No tooltip exists, create a new one
      triggerExplain({ word: synonym, context: '', range: null, contextHash: 0 });
      return;
    }

    // Update current word
    currentWord = synonym;

    // Update header word
    const header = tooltipEl.querySelector('.cursoriq-header .cursoriq-word');
    if (header) {
      header.textContent = synonym;
    }

    // Update explanation text
    const explanationDiv = tooltipEl.querySelector('.cursoriq-explanation');
    if (explanationDiv) {
      explanationDiv.textContent = 'Loading explanation...';
      // Update copy button text reference if it exists
      const copyBtn = tooltipEl.querySelector('.cursoriq-copy-explanation-btn');
      if (copyBtn) {
        copyBtn.dataset.textToCopy = 'Loading explanation...';
      }
    }

    // Remove existing synonyms section
    const existingSynonyms = tooltipEl.querySelector('.cursoriq-synonyms-container');
    if (existingSynonyms) {
      existingSynonyms.remove();
    }

    // Update favorite button to reflect new word
    const favBtn = tooltipEl.querySelector('.cursoriq-fav-btn-icon');
    if (favBtn) {
      updateFavoriteButtonIcon(favBtn, synonym);
    }

    // Fetch explanation for synonym
    try {
      if (!chrome || !chrome.runtime || !chrome.runtime.id) {
        if (explanationDiv) {
          explanationDiv.textContent = 'Extension context invalidated. Please refresh the page.';
          const copyBtn = tooltipEl.querySelector('.cursoriq-copy-explanation-btn');
          if (copyBtn) {
            copyBtn.dataset.textToCopy = 'Extension context invalidated. Please refresh the page.';
          }
        }
        return;
      }
      chrome.runtime.sendMessage({ type: 'explain', word: synonym, context: '' }, (resp) => {
        if (chrome.runtime.lastError) {
          console.error('CursorIQ: Error fetching synonym explanation:', chrome.runtime.lastError);
          if (explanationDiv) {
            const errorText = 'Error: ' + chrome.runtime.lastError.message;
            explanationDiv.textContent = errorText;
            const copyBtn = tooltipEl.querySelector('.cursoriq-copy-explanation-btn');
            if (copyBtn) {
              copyBtn.dataset.textToCopy = errorText;
            }
          }
          return;
        }
        console.log('CursorIQ: Got response for synonym:', resp);
        if (resp && !resp.error) {
          if (explanationDiv) {
            const explanationText = resp.explanation || 'No explanation available.';
            explanationDiv.textContent = explanationText;
            // Update copy button text reference
            const copyBtn = tooltipEl.querySelector('.cursoriq-copy-explanation-btn');
            if (copyBtn) {
              copyBtn.dataset.textToCopy = explanationText;
            }
          }
          // Add synonyms if available
          const newSynonyms = Array.isArray(resp.synonyms) ? resp.synonyms : [];
          console.log('CursorIQ: Adding synonyms to tooltip:', newSynonyms);
          if (newSynonyms.length > 0) {
            addSynonymsToTooltip(newSynonyms);
          } else {
            console.log('CursorIQ: No synonyms to add for synonym');
          }
        } else {
          if (explanationDiv) {
            const errorText = resp?.error || 'Error loading explanation.';
            explanationDiv.textContent = errorText;
            // Update copy button text reference
            const copyBtn = tooltipEl.querySelector('.cursoriq-copy-explanation-btn');
            if (copyBtn) {
              copyBtn.dataset.textToCopy = errorText;
            }
          }
        }
      });
    } catch (e) {
      if (explanationDiv) {
        const errorText = 'Error: ' + (e.message || 'Unknown error');
        explanationDiv.textContent = errorText;
        const copyBtn = tooltipEl.querySelector('.cursoriq-copy-explanation-btn');
        if (copyBtn) {
          copyBtn.dataset.textToCopy = errorText;
        }
      }
    }
  }

  function addSynonymsToTooltip(synonyms) {
    console.log('CursorIQ: addSynonymsToTooltip called with:', synonyms);
    if (!tooltipEl) {
      console.log('CursorIQ: No tooltip element');
      return;
    }
    if (!synonyms || !Array.isArray(synonyms) || synonyms.length === 0) {
      console.log('CursorIQ: No valid synonyms to add');
      return;
    }

    console.log('CursorIQ: Creating synonyms section with', synonyms.length, 'synonyms');

    // Create synonyms section
    const synonymsDiv = document.createElement('div');
    synonymsDiv.className = 'cursoriq-synonyms-container';
    const synonymsLabel = document.createElement('div');
    synonymsLabel.className = 'cursoriq-synonyms-label';
    synonymsLabel.innerHTML = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M8 3H5a2 2 0 00-2 2v3m18 0V5a2 2 0 00-2-2h-3m0 18h3a2 2 0 002-2v-3M3 16v3a2 2 0 002 2h3"/></svg> Synonyms';
    synonymsDiv.appendChild(synonymsLabel);

    const synonymsScroll = document.createElement('div');
    synonymsScroll.className = 'cursoriq-synonyms-scroll';
    synonyms.forEach(synonym => {
      if (!synonym || typeof synonym !== 'string') return;
      const tag = document.createElement('span');
      tag.className = 'cursoriq-synonym-tag';
      tag.textContent = synonym;
      tag.addEventListener('click', (e) => {
        e.stopPropagation();
        console.log('CursorIQ: Synonym clicked:', synonym);
        replaceTooltipWithSynonym(synonym);
      });
      synonymsScroll.appendChild(tag);
    });
    synonymsDiv.appendChild(synonymsScroll);
    
    // Insert before actions div
    const actionsDiv = tooltipEl.querySelector('.cursoriq-actions');
    if (actionsDiv) {
      tooltipEl.insertBefore(synonymsDiv, actionsDiv);
    } else {
      tooltipEl.appendChild(synonymsDiv);
    }
    
    console.log('CursorIQ: Synonyms section added to tooltip');
  }

  function hashString(s) {
    if (!s || typeof s !== 'string') {
      return 0;
    }
    let h = 0;
    for (let i = 0; i < s.length; i++) h = (Math.imul(31, h) + s.charCodeAt(i)) | 0;
    return h >>> 0;
  }

  // Use beforeunload instead of unload (more compatible)
  // But only if allowed - wrap in try-catch
  try {
    window.addEventListener('beforeunload', () => { 
      removeTooltip(); 
    }, { passive: true });
  } catch (e) {
    // Ignore if not allowed by permissions policy
    console.log('CursorIQ: beforeunload listener not allowed on this page');
  }

  // Test: Log when ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
      console.log('CursorIQ: DOM ready');
    });
  } else {
    console.log('CursorIQ: DOM already ready');
  }
  
  // Load modal settings from storage
  function loadModalSettings() {
    chrome.storage.local.get(['settings'], (result) => {
      if (result.settings) {
        modalSettings.placement = result.settings.modalPlacement || 'intuitive';
        modalSettings.draggable = result.settings.modalDraggable !== false;
        modalSettings.showPhonetic = result.settings.showPhonetic !== false;
        modalSettings.showExamples = result.settings.showExamples !== false;
      }
    });
  }
  
  // Listen for settings updates from popup
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === 'settingsUpdated' && message.settings) {
      modalSettings.placement = message.settings.modalPlacement || 'intuitive';
      modalSettings.draggable = message.settings.modalDraggable !== false;
      modalSettings.showPhonetic = message.settings.showPhonetic !== false;
      modalSettings.showExamples = message.settings.showExamples !== false;
      console.log('Nimbus: Settings updated', modalSettings);
    }
  });
  
  // Load settings on initialization
  loadModalSettings();

  // Open hub with person data
  function openHubWithPersonData(personData, searchTerm) {
    console.log('Nimbus: Opening hub with person data for:', searchTerm);
    console.log('Nimbus: Person data image:', personData.image ? 'YES - ' + personData.image : 'NO IMAGE');
    console.log('Nimbus: Full personData:', personData);
    
    // Store person data in chrome.storage for popup to retrieve
    chrome.storage.local.set({
      pendingSearch: {
        type: 'person',
        term: searchTerm,
        data: personData
      }
    }, () => {
      // Try to open the popup - note: this may not work if popup is already open
      // The popup will check for pendingSearch on load
      chrome.runtime.sendMessage({
        action: 'openPopup'
      }, (response) => {
        if (chrome.runtime.lastError) {
          console.log('Nimbus: Could not open popup automatically, user will need to open manually');
        }
      });
    });
  }

  // Show person bio tooltip with image and details (kept for backward compatibility)
  function showPersonTooltip(wordInfo, personData) {
    // Remove any existing tooltip
    removeTooltip();

    tooltipEl = document.createElement('div');
    tooltipEl.className = 'cursoriq-tooltip cursoriq-person-tooltip';
    tooltipEl.style.cssText = 'max-height: 85vh; display: flex; flex-direction: column; overflow: hidden;';
    
    // Make modal draggable if enabled
    if (modalSettings.draggable || modalSettings.placement === 'custom') {
      tooltipEl.style.cursor = 'move';
      let startX, startY, initialX, initialY;
      
      tooltipEl.addEventListener('mousedown', (e) => {
        if (e.target.tagName === 'BUTTON' || e.target.tagName === 'A' || e.target.closest('button') || e.target.closest('a')) {
          return;
        }
        const selection = window.getSelection();
        if (selection && selection.toString().length > 0) {
          return;
        }
        e.preventDefault();
        e.stopPropagation();
        isDragging = true;
        tooltipEl.style.cursor = 'grabbing';
        const rect = tooltipEl.getBoundingClientRect();
        startX = e.clientX;
        startY = e.clientY;
        initialX = rect.left;
        initialY = rect.top;
        document.addEventListener('mousemove', handleDrag);
        document.addEventListener('mouseup', stopDrag);
      });
      
      function handleDrag(e) {
        if (!isDragging) return;
        e.preventDefault();
        const deltaX = e.clientX - startX;
        const deltaY = e.clientY - startY;
        const newX = initialX + deltaX;
        const newY = initialY + deltaY;
        const maxX = window.innerWidth - tooltipEl.offsetWidth;
        const maxY = window.innerHeight - tooltipEl.offsetHeight;
        const finalX = Math.max(0, Math.min(newX, maxX));
        const finalY = Math.max(0, Math.min(newY, maxY));
        tooltipEl.style.left = finalX + 'px';
        tooltipEl.style.top = finalY + 'px';
        tooltipEl.style.position = 'fixed';
        tooltipEl.style.transform = 'none';
        tooltipEl.style.margin = '0';
      }
      
      function stopDrag() {
        isDragging = false;
        tooltipEl.style.cursor = 'move';
        document.removeEventListener('mousemove', handleDrag);
        document.removeEventListener('mouseup', stopDrag);
      }
    }

    // Close button
    const closeBtn = document.createElement('button');
    closeBtn.className = 'cursoriq-close-btn';
    closeBtn.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>';
    closeBtn.setAttribute('aria-label', 'Close');
    closeBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      e.preventDefault();
      manuallyClosed = true;
      if (selectionTimer) {
        clearTimeout(selectionTimer);
        selectionTimer = null;
      }
      const selection = window.getSelection();
      if (selection) {
        selection.removeAllRanges();
      }
      removeTooltip();
    });
    tooltipEl.appendChild(closeBtn);

    // Person image - fixed at top
    if (personData.image) {
      const imageContainer = document.createElement('div');
      imageContainer.style.cssText = 'width: 100%; max-height: 200px; overflow: hidden; border-radius: 8px 8px 0 0; background: #f1f5f9; display: flex; align-items: center; justify-content: center; flex-shrink: 0;';
      const img = document.createElement('img');
      img.src = personData.image;
      img.alt = personData.name;
      img.style.cssText = 'width: 100%; height: auto; max-height: 200px; object-fit: cover; display: block;';
      img.onerror = () => {
        imageContainer.style.display = 'none';
      };
      imageContainer.appendChild(img);
      tooltipEl.appendChild(imageContainer);
    }

    // Person header with name - fixed
    const header = document.createElement('div');
    header.className = 'cursoriq-header';
    header.style.cssText = 'padding: 16px 18px; border-bottom: 1px solid rgba(226, 232, 240, 0.8); flex-shrink: 0;';
    
    const nameDiv = document.createElement('div');
    nameDiv.style.cssText = 'display: flex; align-items: center; justify-content: space-between;';
    
    const nameSpan = document.createElement('span');
    nameSpan.className = 'cursoriq-word';
    nameSpan.textContent = personData.name;
    nameSpan.style.cssText = 'font-size: 20px; font-weight: 700; color: #1e3a8a;';
    nameDiv.appendChild(nameSpan);
    
    // Copy button for name
    const copyBtn = document.createElement('button');
    copyBtn.className = 'cursoriq-copy-btn';
    copyBtn.innerHTML = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path></svg>';
    copyBtn.setAttribute('aria-label', 'Copy name');
    copyBtn.setAttribute('title', 'Copy name');
    copyBtn.style.cssText = 'width: 28px; height: 28px; padding: 0; background: rgba(241, 245, 249, 0.8); border: 1px solid rgba(226, 232, 240, 0.8); border-radius: 6px; color: #64748b; cursor: pointer; display: flex; align-items: center; justify-content: center; opacity: 0.7; transition: all 0.2s ease;';
    copyBtn.addEventListener('click', async (e) => {
      e.stopPropagation();
      e.preventDefault();
      // Only handle if this is our button from our modal
      const personTooltipEl = document.querySelector('.cursoriq-person-tooltip');
      if (!personTooltipEl || !personTooltipEl.contains(e.target)) return;
      
      copyBtn.classList.add('copied');
      try {
        await navigator.clipboard.writeText(personData.name);
      } catch (err) {
        console.error('Failed to copy name', err);
      }
      setTimeout(() => copyBtn.classList.remove('copied'), 300);
    });
    nameDiv.appendChild(copyBtn);
    header.appendChild(nameDiv);
    tooltipEl.appendChild(header);

    // Person details container - scrollable
    const detailsContainer = document.createElement('div');
    detailsContainer.style.cssText = 'padding: 16px 18px; overflow-y: auto; overflow-x: hidden; flex: 1; min-height: 0;';
    
    // Bio/Summary
    if (personData.bio || personData.summary) {
      const bioDiv = document.createElement('div');
      bioDiv.className = 'cursoriq-explanation';
      bioDiv.textContent = personData.bio || personData.summary;
      bioDiv.style.cssText = 'margin-bottom: 16px; line-height: 1.6; color: #334155;';
      detailsContainer.appendChild(bioDiv);
    }

    // Person metadata
    const metadataDiv = document.createElement('div');
    metadataDiv.style.cssText = 'display: flex; flex-direction: column; gap: 8px; font-size: 13px; color: #64748b; margin-bottom: 16px;';
    
    if (personData.birthDate) {
      const birthDiv = document.createElement('div');
      birthDiv.innerHTML = `<strong style="color: #1e3a8a;">Born:</strong> ${personData.birthDate}`;
      metadataDiv.appendChild(birthDiv);
    }
    
    if (personData.occupation) {
      const occDiv = document.createElement('div');
      occDiv.innerHTML = `<strong style="color: #1e3a8a;">Occupation:</strong> ${personData.occupation}`;
      metadataDiv.appendChild(occDiv);
    }
    
    if (personData.nationality) {
      const natDiv = document.createElement('div');
      natDiv.innerHTML = `<strong style="color: #1e3a8a;">Nationality:</strong> ${personData.nationality}`;
      metadataDiv.appendChild(natDiv);
    }
    
    if (metadataDiv.children.length > 0) {
      detailsContainer.appendChild(metadataDiv);
    }

    // Wikipedia link
    if (personData.wikipediaUrl) {
      const wikiLink = document.createElement('a');
      wikiLink.href = personData.wikipediaUrl;
      wikiLink.target = '_blank';
      wikiLink.rel = 'noopener noreferrer';
      wikiLink.textContent = 'Read more on Wikipedia';
      wikiLink.style.cssText = 'display: inline-block; margin-bottom: 16px; color: #1e3a8a; text-decoration: none; font-size: 13px; font-weight: 600; border-bottom: 1px solid #1e3a8a;';
      wikiLink.addEventListener('click', (e) => {
        e.stopPropagation();
      });
      detailsContainer.appendChild(wikiLink);
    }

    // Recent News section
    if (personData.newsArticles && personData.newsArticles.length > 0) {
      // Detect dark mode
      const isDarkMode = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
      const textColor = isDarkMode ? '#ffffff' : '#1e3a8a';
      const textSecondary = isDarkMode ? '#e2e8f0' : '#64748b';
      const textMuted = isDarkMode ? '#cbd5e1' : '#94a3b8';
      
      const newsSection = document.createElement('div');
      newsSection.style.cssText = 'margin-top: 20px; padding-top: 20px; border-top: 1px solid rgba(226, 232, 240, 0.8);';
      
      const newsTitle = document.createElement('div');
      newsTitle.style.cssText = `font-size: 16px; font-weight: 700; color: ${textColor}; margin-bottom: 12px; display: flex; align-items: center; gap: 8px;`;
      newsTitle.innerHTML = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 22h16a2 2 0 0 0 2-2V4a2 2 0 0 0-2-2H8a2 2 0 0 0-2 2v16a2 2 0 0 1-2 2Zm0 0a2 2 0 0 1-2-2v-9c0-1.1.9-2 2-2h2"></path><rect x="11" y="7" width="10" height="5" rx="1"></rect><rect x="11" y="14" width="7" height="5" rx="1"></rect></svg> Recent News';
      newsSection.appendChild(newsTitle);
      
      const newsList = document.createElement('div');
      newsList.style.cssText = 'display: flex; flex-direction: column; gap: 12px;';
      
      personData.newsArticles.forEach((article, index) => {
        const newsItem = document.createElement('div');
        newsItem.style.cssText = 'padding: 12px; background: rgba(241, 245, 249, 0.5); border-radius: 8px; border: 1px solid rgba(226, 232, 240, 0.5); transition: all 0.2s ease; cursor: pointer;';
        
        newsItem.addEventListener('mouseenter', () => {
          newsItem.style.background = 'rgba(241, 245, 249, 0.8)';
          newsItem.style.borderColor = 'rgba(30, 58, 138, 0.3)';
          newsItem.style.transform = 'translateY(-1px)';
        });
        
        newsItem.addEventListener('mouseleave', () => {
          newsItem.style.background = 'rgba(241, 245, 249, 0.5)';
          newsItem.style.borderColor = 'rgba(226, 232, 240, 0.5)';
          newsItem.style.transform = 'translateY(0)';
        });
        
        const articleTitle = document.createElement('div');
        articleTitle.style.cssText = `font-weight: 600; color: ${textColor}; font-size: 14px; margin-bottom: 6px; line-height: 1.4;`;
        articleTitle.textContent = article.title;
        newsItem.appendChild(articleTitle);
        
        if (article.description) {
          const articleDesc = document.createElement('div');
          articleDesc.style.cssText = `font-size: 12px; color: ${textSecondary}; line-height: 1.5; margin-bottom: 8px;`;
          articleDesc.textContent = article.description;
          newsItem.appendChild(articleDesc);
        }
        
        if (article.date) {
          const articleDate = document.createElement('div');
          articleDate.style.cssText = `font-size: 11px; color: ${textMuted}; margin-top: 6px;`;
          // Format date
          try {
            const date = new Date(article.date);
            articleDate.textContent = date.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
          } catch (e) {
            articleDate.textContent = article.date;
          }
          newsItem.appendChild(articleDate);
        }
        
        newsItem.addEventListener('click', (e) => {
          e.stopPropagation();
          if (article.link) {
            window.open(article.link, '_blank', 'noopener,noreferrer');
          }
        });
        
        newsList.appendChild(newsItem);
      });
      
      newsSection.appendChild(newsList);
      detailsContainer.appendChild(newsSection);
    }

    tooltipEl.appendChild(detailsContainer);
    document.body.appendChild(tooltipEl);
    
    // Position the tooltip
    positionTooltip(tooltipEl, wordInfo);
    
    currentWord = personData.name;
  }

})();
